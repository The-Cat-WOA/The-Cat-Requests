package com.woa.bot

import android.content.Context
import android.graphics.BitmapFactory
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Pt(val x: Int, val y: Int)
data class Row(val x: Int, val y: Int, val score: Float)

/** Bilderkennung (Port der Python-Version). Alle Frames sind RGBA-Mats. */
class Vision(ctx: Context) {

    companion object {
        // Abstaende zum "+"-Button im Referenz-Screenshot (Pixel bei Skalierung 1.0)
        val HANDLE = Pair(-343, 0)
        val DRAG_TO = Pair(-30, 0)
        val WARN = Pair(-227, -44)
        val TOGGLE = Pair(-4, 80)
        val BUTTON = Pair(-683, 266)

        const val LIST_X0 = 0.70
        const val LIST_X1 = 0.995
        const val ANCHOR_X1 = 0.85
        const val PLANE_THRESH = 0.58f
        const val CLAIM_THRESH = 0.78f

        private val YL = Scalar(201.0, 151.0, 0.0, 0.0)     // gelb: R>200, G>150, B<90
        private val YH = Scalar(255.0, 255.0, 89.0, 255.0)
        private val GL = Scalar(0.0, 151.0, 0.0, 0.0)       // gruen (Schalter an)
        private val GH = Scalar(129.0, 255.0, 255.0, 255.0)
    }

    private fun load(ctx: Context, name: String): Mat {
        val bmp = ctx.assets.open("templates/$name").use { BitmapFactory.decodeStream(it) }
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        val g = Mat()
        Imgproc.cvtColor(rgba, g, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()
        return g
    }

    private val plane = load(ctx, "plane_icon.png")
    private val plus = load(ctx, "plus.png")
    private val warn = load(ctx, "warn.png")
    private val takeoff = load(ctx, "takeoff_icon.png")
    private val claim = load(ctx, "claim_button.png")
    private val popUp = load(ctx, "popup_upgrade.png")
    private val popCa = load(ctx, "popup_cancel.png")
    private val popXp = load(ctx, "popup_xp.png")

    fun gray(rgba: Mat): Mat {
        val g = Mat()
        Imgproc.cvtColor(rgba, g, Imgproc.COLOR_RGBA2GRAY)
        return g
    }

    // ---------------------------------------------------------------- Grundbausteine
    private fun scaled(t: Mat, s: Double): Mat {
        if (abs(s - 1.0) < 0.02) return t
        val out = Mat()
        Imgproc.resize(t, out, Size(), s, s, if (s < 1) Imgproc.INTER_AREA else Imgproc.INTER_LINEAR)
        return out
    }

    private class Match(val res: Mat, val t: Mat)

    private fun match(g: Mat, tpl: Mat, s: Double): Match? {
        val t = scaled(tpl, s)
        if (g.rows() < t.rows() || g.cols() < t.cols()) return null
        val res = Mat()
        Imgproc.matchTemplate(g, t, res, Imgproc.TM_CCOEFF_NORMED)
        return Match(res, t)
    }

    /** Bester Treffer ab Schwelle: Mittelpunkt (plus Verschiebung ox/oy) oder null. */
    private fun hit(g: Mat, tpl: Mat, s: Double, thresh: Double, ox: Int = 0, oy: Int = 0): Pt? {
        val m = match(g, tpl, s) ?: return null
        val r = Core.minMaxLoc(m.res)
        m.res.release()
        if (r.maxVal < thresh) return null
        return Pt((r.maxLoc.x + m.t.cols() / 2.0).toInt() + ox, (r.maxLoc.y + m.t.rows() / 2.0).toInt() + oy)
    }

    private fun yellowFrac(rgba: Mat, x: Int, y: Int, w: Int, h: Int): Double {
        val x0 = max(0, x)
        val y0 = max(0, y)
        val x1 = min(rgba.cols(), x + w)
        val y1 = min(rgba.rows(), y + h)
        if (x1 <= x0 || y1 <= y0) return 0.0
        val sub = rgba.submat(Rect(x0, y0, x1 - x0, y1 - y0))
        val m = Mat()
        Core.inRange(sub, YL, YH, m)
        val n = Core.countNonZero(m)
        m.release()
        return n.toDouble() / ((x1 - x0) * (y1 - y0))
    }

    fun off(a: Pt, k: Pair<Int, Int>, s: Double): Pt =
        Pt((a.x + k.first * s).toInt(), (a.y + k.second * s).toInt())

    // ---------------------------------------------------------------- Skalierung
    /** Sucht die passende Skalierung anhand der Flugzeug-Symbole. Gibt (Treffer, Skalierung) zurueck. */
    fun calibrate(g: Mat): Pair<Double, Double> {
        val w = g.cols()
        val h = g.rows()
        val x0 = (w * LIST_X0).toInt()
        val x1 = (w * LIST_X1).toInt()
        val strip = g.submat(Rect(x0, 0, x1 - x0, h))
        var best = 0.0
        var bestScale = 1.0
        var step = 0
        while (step <= 42) {
            val s = 0.5 + step * 0.05
            val m = match(strip, plane, s)
            if (m != null) {
                val mx = Core.minMaxLoc(m.res).maxVal
                if (mx > best) {
                    best = mx
                    bestScale = Math.round(s * 100) / 100.0
                }
                m.res.release()
            }
            step++
        }
        return Pair(best, bestScale)
    }

    // ---------------------------------------------------------------- Liste rechts
    private fun findRows(rgba: Mat, g: Mat, s: Double, tpl: Mat, thresh: Float): List<Row> {
        val w = g.cols()
        val h = g.rows()
        val x0 = (w * LIST_X0).toInt()
        val x1 = (w * LIST_X1).toInt()
        val m = match(g.submat(Rect(x0, 0, x1 - x0, h)), tpl, s) ?: return emptyList()
        val rw = m.res.cols()
        val rh = m.res.rows()
        val arr = FloatArray(rw * rh)
        m.res.get(0, 0, arr)
        m.res.release()
        val cand = ArrayList<Int>()
        for (i in arr.indices) if (arr[i] >= thresh) cand.add(i)
        cand.sortByDescending { arr[it] }
        val picked = ArrayList<Row>()
        for (i in cand.take(3000)) {
            val cx = i % rw + x0 + m.t.cols() / 2
            val cy = i / rw + m.t.rows() / 2
            if (picked.any { abs(cy - it.y) < 25 * s && abs(cx - it.x) < 25 * s }) continue
            val r = (12 * s).toInt()
            if (yellowFrac(rgba, cx - r, (cy - 36 * s).toInt() - r, 2 * r, 2 * r) <= 0.04) continue
            picked.add(Row(cx, cy, arr[i]))
        }
        return picked.sortedBy { it.y }
    }

    fun findPlanes(rgba: Mat, g: Mat, s: Double) = findRows(rgba, g, s, plane, PLANE_THRESH)
    fun findClaims(rgba: Mat, g: Mat, s: Double) = findRows(rgba, g, s, takeoff, CLAIM_THRESH)

    // ---------------------------------------------------------------- Personal-Fenster
    fun findAnchor(g: Mat, s: Double): Pt? {
        val y0 = (g.rows() * 0.35).toInt()
        val sub = g.submat(Rect(0, y0, (g.cols() * ANCHOR_X1).toInt(), g.rows() - y0))
        return hit(sub, plus, s, 0.85, 0, y0)
    }

    fun warnPresent(g: Mat, anchor: Pt, s: Double): Boolean {
        val c = off(anchor, WARN, s)
        val m = (40 * s).toInt()
        val x0 = max(0, c.x - m)
        val y0 = max(0, c.y - m)
        val x1 = min(g.cols(), c.x + m)
        val y1 = min(g.rows(), c.y + m)
        if (x1 <= x0 || y1 <= y0) return false
        val mm = match(g.submat(Rect(x0, y0, x1 - x0, y1 - y0)), warn, s) ?: return false
        val mx = Core.minMaxLoc(mm.res).maxVal
        mm.res.release()
        return mx > 0.65
    }

    fun toggleOn(rgba: Mat, anchor: Pt, s: Double): Boolean {
        val c = off(anchor, TOGGLE, s)
        val w = (40 * s).toInt()
        val h = (14 * s).toInt()
        val x0 = max(0, c.x - w)
        val y0 = max(0, c.y - h)
        val x1 = min(rgba.cols(), c.x + w)
        val y1 = min(rgba.rows(), c.y + h)
        if (x1 <= x0 || y1 <= y0) return false
        val m = Mat()
        Core.inRange(rgba.submat(Rect(x0, y0, x1 - x0, y1 - y0)), GL, GH, m)
        val frac = Core.countNonZero(m).toDouble() / ((x1 - x0) * (y1 - y0))
        m.release()
        return frac > 0.15
    }

    /** Helles Gelb = "Beginne die Abfertigung" (voll besetzt); dunkel = nicht moeglich. */
    fun buttonBright(rgba: Mat, anchor: Pt, s: Double): Boolean {
        val c = off(anchor, BUTTON, s)
        val rs = ArrayList<Double>()
        val gs = ArrayList<Double>()
        val bs = ArrayList<Double>()
        for (dx in intArrayOf(-120, -100, 100, 120)) {
            for (dy in intArrayOf(-8, 0, 8)) {
                val x = (c.x + dx * s).toInt()
                val y = (c.y + dy * s).toInt()
                if (x in 0 until rgba.cols() && y in 0 until rgba.rows()) {
                    val p = rgba.get(y, x)
                    rs.add(p[0]); gs.add(p[1]); bs.add(p[2])
                }
            }
        }
        if (rs.isEmpty()) return false
        fun med(l: ArrayList<Double>): Double { l.sort(); return l[l.size / 2] }
        return med(rs) > 185 && med(gs) > 145 && med(bs) < 90
    }

    // ---------------------------------------------------------------- Gelbe Flaechen-Buttons
    /** Gelber, gefuellter Button (egal welcher Text) im Bereich. Groessen in Referenz-Pixeln. */
    private fun filledYellow(
        rgba: Mat, x0: Int, x1: Int, y0: Int, y1: Int, s: Double,
        wMin: Double, wMax: Double, hMin: Double, hMax: Double
    ): Pt? {
        if (x1 <= x0 || y1 <= y0) return null
        val mask = Mat()
        Core.inRange(rgba.submat(Rect(x0, y0, x1 - x0, y1 - y0)), YL, YH, mask)
        val k = max(3, (9 * s).toInt() or 1)
        val ker = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(k.toDouble(), k.toDouble()))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, ker)
        val labels = Mat()
        val stats = Mat()
        val cents = Mat()
        val n = Imgproc.connectedComponentsWithStats(mask, labels, stats, cents)
        var best: Pt? = null
        var bestArea = 0.0
        for (i in 1 until n) {
            val x = stats.get(i, Imgproc.CC_STAT_LEFT)[0]
            val y = stats.get(i, Imgproc.CC_STAT_TOP)[0]
            val w = stats.get(i, Imgproc.CC_STAT_WIDTH)[0]
            val h = stats.get(i, Imgproc.CC_STAT_HEIGHT)[0]
            val a = stats.get(i, Imgproc.CC_STAT_AREA)[0]
            if (w >= wMin * s && w <= wMax * s && h >= hMin * s && h <= hMax * s && a >= 0.8 * w * h && a > bestArea) {
                best = Pt((x0 + x + w / 2).toInt(), (y0 + y + h / 2).toInt())
                bestArea = a
            }
        }
        mask.release(); labels.release(); stats.release(); cents.release()
        return best
    }

    /** "Belohnungen einfordern" links unten: erst Vorlage, sonst gelber Button (jede Sprache). */
    fun findClaimButton(rgba: Mat, g: Mat, s: Double): Pt? {
        val w = g.cols()
        val h = g.rows()
        val y0 = (h * 0.5).toInt()
        val viaTpl = hit(g.submat(Rect(0, y0, (w * 0.5).toInt(), h - y0)), claim, s, 0.7, 0, y0)
        if (viaTpl != null) return viaTpl
        return filledYellow(rgba, 0, (w * 0.30).toInt(), (h * 0.78).toInt(), h, s, 230.0, 420.0, 36.0, 70.0)
    }

    // ---------------------------------------------------------------- Praemien-Fenster
    private fun findPrimary(rgba: Mat, s: Double): Pt? {
        val w = rgba.cols()
        val h = rgba.rows()
        return filledYellow(rgba, (w * 0.20).toInt(), (w * 0.80).toInt(), (h * 0.45).toInt(), (h * 0.88).toInt(),
            s, 180.0, 520.0, 32.0, 64.0)
    }

    /** Liefert (gelber Haupt-Button, Stornieren-Button); beide null, wenn kein Praemien-Fenster offen ist. */
    fun findPopup(rgba: Mat, g: Mat, s: Double): Pair<Pt?, Pt?> {
        val w = g.cols()
        val h = g.rows()
        val bx = (w * 0.15).toInt()
        val by = (h * 0.45).toInt()
        val band = g.submat(Rect(bx, by, (w * 0.70).toInt(), (h * 0.45).toInt()))
        val upT = hit(band, popUp, s, 0.75, bx, by)
        val caT = hit(band, popCa, s, 0.75, bx, by)
        var ctx: Pt? = upT ?: caT
        if (ctx == null) {
            val x0 = (w * 0.20).toInt()
            val y0 = (h * 0.30).toInt()
            ctx = hit(g.submat(Rect(x0, y0, (w * 0.60).toInt(), (h * 0.48).toInt())), popXp, s, 0.7, x0, y0)
        }
        if (ctx == null) return Pair(null, null)
        val primary = upT ?: findPrimary(rgba, s)
        val cancel = caT ?: primary?.let { Pt((it.x + 354 * s).toInt(), it.y) }
        return Pair(primary, cancel)
    }
}
