package com.woa.bot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.Rect
import kotlin.math.max
import kotlin.math.min

/** Vordergrunddienst: Bildschirmaufnahme + Bot-Thread. */
class BotService : Service() {

    companion object {
        const val ACTION_START = "com.woa.bot.START"
        const val ACTION_STOP = "com.woa.bot.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "bot"
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var core: BotCore? = null
    private var thread: Thread? = null
    private var lastFrame: Mat? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.action == ACTION_START) {
            promoteToForeground()
            val code = intent.getIntExtra(EXTRA_CODE, 0)
            val data = readData(intent)
            if (data == null) {
                shutdown()
            } else if (thread == null) {
                startBot(code, data)
            }
        } else {
            shutdown()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(intent: Intent): Intent? = intent.getParcelableExtra(EXTRA_DATA)

    private fun promoteToForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "WoA Crew Bot", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, BotService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause),
            getString(R.string.btn_stop), stopPi
        ).build()
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .addAction(action)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun startBot(code: Int, data: Intent) {
        if (!OpenCVLoader.initLocal()) {
            Bus.log(getString(R.string.log_error, "OpenCV"))
            shutdown()
            return
        }
        Bus.reset()
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    Handler(Looper.getMainLooper()).post { shutdown() }
                }
            }, Handler(Looper.getMainLooper()))

            val dm = DisplayMetrics()
            getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
            val w = max(dm.widthPixels, dm.heightPixels)      // Spiel laeuft im Querformat
            val h = min(dm.widthPixels, dm.heightPixels)
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            vdisplay = p.createVirtualDisplay(
                "woa", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
        } catch (e: Exception) {
            Bus.log(getString(R.string.log_error, e.message ?: e.toString()))
            shutdown()
            return
        }

        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val cfg = BotCfg(
            ramp = prefs.getBoolean("ramp", true),
            claim = prefs.getBoolean("claim", true),
            maint = prefs.getBoolean("maint", true),
            popupYellow = prefs.getBoolean("yellow", true)
        )
        thread = Thread {
            try {
                val c = BotCore(applicationContext, { grabFrame() }, cfg)
                core = c
                c.run()
            } catch (e: Exception) {
                Bus.log(getString(R.string.log_error, e.message ?: e.toString()))
            } finally {
                Handler(Looper.getMainLooper()).post { cleanup() }
            }
        }.also { it.start() }
    }

    /** Neuestes Bild als RGBA-Mat (bei unveraendertem Bildschirm das letzte). */
    private fun grabFrame(): Mat? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            try {
                val plane = img.planes[0]
                val bmpW = plane.rowStride / plane.pixelStride
                val bmp = Bitmap.createBitmap(bmpW, img.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(plane.buffer)
                val full = Mat()
                Utils.bitmapToMat(bmp, full)
                bmp.recycle()
                val frame = if (bmpW != img.width) Mat(full, Rect(0, 0, img.width, img.height)).clone() else full
                lastFrame = frame
            } finally {
                img.close()
            }
        }
        return lastFrame
    }

    /** STOPP: Bot-Thread beenden lassen; er raeumt danach selbst auf (kein Blockieren des Hauptthreads). */
    private fun shutdown() {
        core?.stop = true
        val t = thread
        if (t != null && t.isAlive) return
        cleanup()
    }

    private fun cleanup() {
        try { vdisplay?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        vdisplay = null
        reader = null
        projection = null
        lastFrame = null
        thread = null
        core = null
        Bus.running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        core?.stop = true
        super.onDestroy()
    }
}
